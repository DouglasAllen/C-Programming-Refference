//Program P1.2
#include <stdio.h>
int main() {
   printf("Where the mind is without fear\n");
   printf("And the head is held high\n");
}
