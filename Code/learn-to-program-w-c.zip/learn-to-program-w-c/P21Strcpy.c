//Program P2.1
#include <stdio.h>  //needed for printf
#include <string.h>  // needed for strcpy
int main() {
   char name[50];
   strcpy(name, "Alice in Wonderland");
   printf("Hello, %s\n", name);
}
