//Program P1.3
// This program prints the sum of 14 and 25. It shows how
// to declare variables in C and assign values to them.
#include <stdio.h>
int main() {
   int a, b, sum;
   a = 14;
   b = 25;
   sum = a + b;
   printf("%d + %d = %d\n", a, b, sum);
}
