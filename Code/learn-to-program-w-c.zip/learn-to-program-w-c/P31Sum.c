//Program P3.1
#include <stdio.h>
int main() {
	int a = 14;
	int b = 25;
	int sum = a + b;
	printf("%d + %d = %d\n", a, b, sum);
}
