//Program P3.2
#include <stdio.h>
int main() {
   int a = 14;
   int b = 25;
   printf("%d + %d = %d\n", a, b, a + b);
}
