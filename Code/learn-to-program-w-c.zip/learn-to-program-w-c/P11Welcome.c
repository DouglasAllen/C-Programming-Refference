//Program P1.1
#include <stdio.h>
int main() {
   printf("Welcome to Trinidad & Tobago");
}
