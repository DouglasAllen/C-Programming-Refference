// Program P5.10
#include <stdio.h>
int main() {
   int h;
   for (h = 1; h <= 5; h++)
      printf("I must not sleep in class\n");
}
