// Program P5.11
#include <stdio.h>
int main() {
   for (int h = 1; h <= 5; h++)
      printf("%d. I must not sleep in class\n", h);
}
