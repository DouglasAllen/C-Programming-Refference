// Program P5.13
#include <stdio.h>
int main() {
   for (int m = 1; m <= 12; m++)
      printf("%2d x 2 = %2d\n", m, m * 2);
}
