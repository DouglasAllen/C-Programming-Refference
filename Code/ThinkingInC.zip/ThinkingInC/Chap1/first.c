/* first.c: A First Program */

#include <stdio.h>

int main()
{
    puts("** Welcome to Thinking in C **");
    puts("(You'll be glad you came!)");
    return 0;
}

