/* gcc -o ex02 ex02.c */

#include <stdio.h>

void main(void){
	printf("The number of students in %s is %d.\n",
            "CS415", 80);
}
