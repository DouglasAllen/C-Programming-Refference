/* Hello World program */
/* gcc -o ex01 ex01.c */

#include <stdio.h>

void main(void){
	printf("Hello World.\n");
}
