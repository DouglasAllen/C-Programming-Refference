#! /bin/bash
# Makes all c files in current directory
ls ./*.c | xargs -L 1 echo | sed -e 's/\.c//g' | xargs rm -f
