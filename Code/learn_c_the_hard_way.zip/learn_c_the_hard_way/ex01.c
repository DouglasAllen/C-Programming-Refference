#include <stdio.h>

int main(int argc, char *argv[])
{
  puts("Hello world.");

  return 0;
}
