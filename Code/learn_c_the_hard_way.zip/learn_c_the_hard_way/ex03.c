#include <stdio.h>
#include <time.h>

int main()
{
    int age    = 27;
    int height = 72;

    printf("I am %d years old.\n", age);
    printf("I am %d inches tall.\n", height);

    return 0;
}
