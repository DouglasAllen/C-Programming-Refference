/*-*/
/********************************************************
 * Name:						*
 *	Very Simple					*
 * 							*
 * Purpose:						*
 *	This is a very simple demonstration of 		*
 *	expressions.  					*
 *							*
 * Notes:						*
 * 	Although it calculates an answer, it doesn't	*
 *	tell anyone about.  So this program is 		*
 *	pretty much useless except as a demonstration	*
 *	program.					*
 ******************************************************/
/*+*/
int main()
{
    (1 + 2) * 4;
    return (0);
}
