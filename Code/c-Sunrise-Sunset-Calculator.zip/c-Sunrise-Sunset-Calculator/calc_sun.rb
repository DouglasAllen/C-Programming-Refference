
#
module MM
  include Math
  def to_deg(value)
    value * 57.295779513082320876798154814105
  end

  def to_rad(value)
    value * 0.017453292519943295769236907684886
  end
end

require 'date'
#
class CalcSun
  include MM

  attr_accessor :year, :month, :day, :latitude, :longitude

  def initialize(y, m, d, lat, lon)
    @year = y
    @month = m
    @day = d
    @latitude = lat
    @longitude = lon
  end

  def mean_local_noon
    # (julian_date - 2_451_545 + 0.00079 - @longitude / 360)
    (julian_date - 2_451_545 - @longitude / 360)
  end

  def julian_date
    Date.new(@year, @month, @day).jd
  end

  def pi
    PI
  end

  def pi2
    pi * 2
  end

  def mean_anomally
    to_rad((357.5291 + 0.9856002817560271 * mean_local_noon) % 360)
  end

  def equation_of_center
    ma = mean_anomally
    to_rad(1.9148 * sin(ma) + 0.0200 * sin(2 * ma) + 0.0003 * sin(3 * ma))
  end

  def true_anomally
    mean_anomally + equation_of_center
  end

  def mean_longitude
    to_rad(280.4664567 + 0.9856473601037645 * mean_local_noon) % pi2
  end

  def eccentricity
    0.016709 - 1.151e-9 * mean_local_noon
  end

  def eccentric_anomaly
    ml = mean_longitude
    e = eccentricity
    ml + e * sin(ml) * (1.0 + e * cos(ml))
  end

  def obliquity_of_ecliptic
    to_rad(23.439291 - 3.563E-7 * mean_local_noon)
  end

  def xv
    cos(eccentric_anomaly) - eccentricity
  end

  def yv
    sqrt(1.0 - eccentricity * eccentricity) * sin(eccentric_anomaly)
  end

  def rv
    sqrt(xv * xv + yv * yv)
  end

  def longitude_of_perihelion
    to_rad(282.9404 + 4.70935e-05 * mean_local_noon) % pi2
  end

  def argument_of_perihelion
    (mean_longitude - longitude_of_perihelion) % pi2
  end

  def test_true_anomally
    atan2(yv, xv)# /* True anomaly */
  end

  def test_true_longitude
    w = argument_of_perihelion
    v = test_true_anomally
    (v + w) % pi2 # /* True solar longitude */
  end

  def true_longitude
    w = longitude_of_perihelion
    v = true_anomally
    (v + w) % pi2 # /* True solar longitude */
  end

  def ecliptic_x
    rv * cos(true_longitude)
  end

  def ecliptic_y
    rv * sin(true_longitude)
  end


  def right_ascension
    y = ecliptic_y * cos(obliquity_of_ecliptic)
    x = ecliptic_x
    ra = atan2(y, x)
    ra < 0 ? pi2 + ra : ra
  end

  def declination
    x1 = ecliptic_x
    y1 = ecliptic_y
    z1 = y1 * sin(obliquity_of_ecliptic)
    atan2(z1, sqrt(x1 * x1 + y1 * y1))
  end

  def sidereal_time
    to_rad(180 + 357.52911 + 282.9404 + (0.985600281725 + 4.70935E-5) * mean_local_noon) % pi2
  end

  def eot
    mean_anomally - true_anomally + true_longitude - right_ascension
  end
end

require 'test/unit'
#
class TestCalcSun < Test::Unit::TestCase
  include MM

  def setup
    @cs = CalcSun.new(2000, 1, 1, 0, 0)
  end

  def teardown
    ## Nothing really
  end

  def test_init
    assert_equal(2000, @cs.year)
    assert_equal(1, @cs.month)
    assert_equal(1, @cs.day)
    assert_equal(0, @cs.latitude)
    assert_equal(0, @cs.longitude)
  end

  def test_julian_date
    assert_equal(2_451_545, @cs.julian_date)
  end

  def test_mean_local_noon
    assert_equal(0, @cs.mean_local_noon)
  end

  def test_mean_anomally
    assert_equal(6.240059966692059, @cs.mean_anomally)
    assert_equal(357.5291, to_deg(@cs.mean_anomally))
  end

  def test_equation_of_center
    assert_equal(-0.0014715287836893668, @cs.equation_of_center)
    assert_equal(-0.08431238873742017, to_deg(@cs.equation_of_center))
  end

  def test_true_anomally
    assert_equal(6.23858843790837, @cs.true_anomally)
    assert_equal(357.44478761126265, to_deg(@cs.true_anomally))
  end

  def test_mean_longitude
    assert_equal(4.89506311081711, @cs.mean_longitude)
    assert_equal(280.4664567, to_deg(@cs.mean_longitude))
  end

  def test_eccentricity
    assert_equal(0.016709, @cs.eccentricity)
  end

  def test_eccentric_anomaly
    assert_equal(4.8785822508615935, @cs.eccentric_anomaly)
    assert_equal(279.5221729818027, to_deg(@cs.eccentric_anomaly))
  end

  def test_obliquity_of_ecliptic
    assert_equal(0.4090928022830742, @cs.obliquity_of_ecliptic)
    assert_equal(23.439291, to_deg(@cs.obliquity_of_ecliptic))
  end

  def test_xv
    assert_equal(0.14872027767348, @cs.xv)
  end

  def test_yv
    assert_equal(-0.9860839740994566, @cs.yv)
  end

  def test_longitude_of_perihelion
    assert_equal(4.938241566909764, @cs.longitude_of_perihelion)
    assert_equal(282.9404, to_deg(@cs.longitude_of_perihelion))
  end

  def test_test_true_longitude
    assert_equal(4.818901431620795, @cs.test_true_longitude)
  end

  def test_true_longitude
    assert_equal(4.893644697638548, @cs.true_longitude)
    assert_equal(280.38518761126267, to_deg(@cs.true_longitude))
  end

  def test_rv
    assert_equal(0.9972358421993539, @cs.rv)
  end

  def test_ecliptic_x
    assert_equal(0.1797665809291078, @cs.ecliptic_x)
  end

  def test_ecliptic_y
    assert_equal(-0.9808992309855856, @cs.ecliptic_y)
  end

  def test_right_ascension
    assert_equal(4.909544229885129, @cs.right_ascension)
  end

  def test_declination
    assert_equal(-0.37294996573991546, @cs.declination)
  end

  def test_sidereal_time
    assert_equal(0, @cs.sidereal_time)
  end
end

