#include <iostream>
#include <time.h>
#include <cmath>

#define _USE_MATH_DEFINES

using namespace std;

void calcDayYear(int *dayOfYear)
{	
	int day, month, year;
	day = 22;
	month = 11;
	year = 2016;
	// cout<<"What day of the month is it? ";
	// cin>>day;
	// cout<<""<<endl;
	// cout<<"What month is it? ";
	// cin>>month;
	// cout<<""<<endl;
	// cout<<"What year is it? ";
	// cin>>year;
	// cout<<""<<endl;	

	//determine day of year
	int n1, n2, n3;
	n1 = floor(275 * month / 9); 	

	n2 = floor((month + 9) / 12); 									

	n3 = (1 + floor((year - 4 * floor(year / 4) + 2) / 3));				

	*dayOfYear = n1 - (n2 * n3) + day - 30;
}

void convLong(int *lngHour, int *tRise, int *tSet, int *dayOfYear)
{
	int longitude;
	// cout<<"What is your longitude? ";
	// cin>>longitude;
	// cout<<""<<endl;
	longitude = -88.75;
	*lngHour = longitude/15;

	*tRise = *dayOfYear+((6-*lngHour)/24);
	*tSet = *dayOfYear + ((118-*lngHour)/24);
}

void calcSMeanAnomaly(int *smaRise, int *smaSet, int *tRise, int *tSet)
{
	*smaRise = (.9856 * (*tRise)) - 3.289;
	*smaSet = (.9856 * (*tRise)) - 3.289;
}

void calcSunTrueLongitude(int *smaRise, double *sunTrueLongitudeRise)
{
	*sunTrueLongitudeRise = *smaRise +(1.916 * sin(*smaRise)) + (0.020 + sin(2+*smaRise)) + 282.634;
}

void calcSunRightAscension(double *sunTrueLongitudeRise, double *sunRightAscension)
{
	*sunRightAscension = atan(.91764 * tan(*sunTrueLongitudeRise));
}

int main() 
{
	int dayOfYear, lngHour, tRise, tSet, smaRise, smaSet;
	double sunTrueLongitudeRise;
	double sunRightAscension;

	calcDayYear(&dayOfYear);
	convLong(&lngHour, &tRise, &tSet, &dayOfYear);
	calcSMeanAnomaly(&smaRise, &smaSet, &tRise, &tSet);
	calcSunTrueLongitude(&smaRise, &sunTrueLongitudeRise);
	calcSunRightAscension(&sunTrueLongitudeRise, &sunRightAscension);

	cout << fmod(sunTrueLongitudeRise, 360) << endl;
	cout << sunRightAscension * 180 / M_PI  << endl;
    cout << smaRise  << endl;
	cout << smaSet  << endl;
	cout << dayOfYear << endl;	
}


