/* Exercise 1.1 Output a name and address */
#include <stdio.h>

int main(void)
{
  printf("\nGeorge Washington");
  printf("\n3200 George Washington Memorial Parkway");
  printf("\nMount Vernon");
  printf("\nVirginia 22121\n");
  return 0;
}
