/* Program 2.2 Using a variable  */
#include <stdio.h>

int main(void)
{
  int salary;            /* Declare a variable called salary         */
  salary = 10000;        /* A simple arithmetic assignment statement */
  printf("My salary is %d.", salary);
  return 0;
}

