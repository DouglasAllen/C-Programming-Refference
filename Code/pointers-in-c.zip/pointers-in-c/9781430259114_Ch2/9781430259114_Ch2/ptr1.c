int main()   
{
   int var_int ;
   printf(�Insert data\n�);
   scanf(�%d�, &var_int); 
   return 0; 
}