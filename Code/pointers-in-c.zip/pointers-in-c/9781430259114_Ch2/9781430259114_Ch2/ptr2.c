int main()
{
	int var_int = 40;
	printf (“Address of variable “var_int” %p\n”, &var_int);
}