#include<stdio.h>	
int main()
{		
	printf(“Hello World example\n”);                                                           
 	return 0;
}