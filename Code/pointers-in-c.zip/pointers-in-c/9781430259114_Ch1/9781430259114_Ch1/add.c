int add(int v1, int v2)
{
	return v1+v2;
}
int main(int argc, char* argv[])
{
	int a = 10;
	int b = 20;
	int z = add(10,20);
	return 0;
}
