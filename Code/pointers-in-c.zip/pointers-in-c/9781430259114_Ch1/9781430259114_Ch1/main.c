static int staticglobal = 1;
int initglobal = 10;
int uninitglobal;
void main()
{		
	return;
}
