static int uninitstaticglbl;
int uninitglobal;
void main()
{
	return;
}
