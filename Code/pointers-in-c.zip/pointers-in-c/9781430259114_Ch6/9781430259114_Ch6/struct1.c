int main(int argc, char* argv[])
{													
	struct date											
	{														
		int day;												
		int month;												
		int year;										
	};												
	struct date current;										
	current.day = 1;										
	current.month = 11;										
	current.year = 2012;										
	return 0;
}
