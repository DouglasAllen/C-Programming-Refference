#include <stdio.h>
#include <malloc.h>
int main()											                  
{														
	char arrstr[6];
	char* strptr;
	printf(“Input hello\n”);
	scanf(“%s”, arrstr);
	printf(“String received = %s\n”,arrstr);
}
