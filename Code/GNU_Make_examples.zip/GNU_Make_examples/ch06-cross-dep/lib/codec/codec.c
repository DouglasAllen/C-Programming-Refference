#include <codec/codec.h>

int
codec()
{
  return 0;
}
