#include <ui/ui.h>
#include <db/playlist.h>

int
ui()
{
  return 0;
}
