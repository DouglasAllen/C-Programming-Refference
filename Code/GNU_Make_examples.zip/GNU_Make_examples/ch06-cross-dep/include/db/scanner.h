#ifndef LEXER_H_
#define LEXER_H_

extern int yylex( void );

#endif
