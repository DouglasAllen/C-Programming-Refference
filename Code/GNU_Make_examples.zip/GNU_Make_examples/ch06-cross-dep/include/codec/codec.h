#ifndef CODEC_H_
#define CODEC_H_

extern int
codec();

#endif
