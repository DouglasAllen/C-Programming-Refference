#ifdef COUNTER_H_
#define COUNTER_H_

extern void
counter( int counts[4] );

#endif
