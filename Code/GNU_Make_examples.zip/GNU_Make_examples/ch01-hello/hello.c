#include <stdio.h>

main( int argc, char *argv[] )
{
    printf( "Hello, world\n" );
}
