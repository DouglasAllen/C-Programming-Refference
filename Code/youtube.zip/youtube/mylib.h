#ifndef MYLIB_H_INCLUDED
#define MYLIB_H_INCLUDED



#endif // MYLIB_H_INCLUDED

int AddInt(int i1, int i2);
void get_time_now();
