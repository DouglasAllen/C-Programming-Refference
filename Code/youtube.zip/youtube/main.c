#include <stdio.h>
#include <stdlib.h>
#include "mylib.h"

int main()
{
    printf("Hello world!\n");
    printf("%i \n", AddInt(1, 2));
    get_time_now();
    return 0;
}
