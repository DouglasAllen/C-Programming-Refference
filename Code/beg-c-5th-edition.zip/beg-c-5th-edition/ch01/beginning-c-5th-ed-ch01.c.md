
# Beginning C 5th ed

## Chapter One Listings

```code
/* Program 1.1 Your Very First C Program - Displaying Hello World */
#include <stdio.h>

int main(void)
{
  printf("Hello world!");
  return 0;
}
```

```code
/* Program 1.2 Your Second C Program */
#include<stdio.h>

int main(void)
{
  printf("If at first you don\'t succeed, try, try, try again!");
  return 0;
}
```

```code
/* Program 1.3 Another Simple C Program - Displaying a Quotation */
#include <stdio.h>           // This is a preprocessor directive

int main(void)               // This identifies the function main()
{                            // This marks the beginning of main()
  printf("Beware the Ides of March!");  // This line outputs a quotation
  return 0;                  // This returns control to the operating system
}                            // This marks the end of main()
```

```code
/* Program 1.4 Another Simple C Program - Displaying a Quotation */
#include <stdio.h>

int main(void)
{
  printf("My formula for success?\nRise early, work late, strike oil.\n");
  return 0;
}
```

```code
// Program 1.5 Another Simple C Program - Displaying Great Quotations
#include <stdio.h>

int main(void)
{
  printf("\"It is a wise father that knows his own child.\"\nShakespeare\n");
  return 0;
}
```

```code
// Program 1.6 A Simple C Program - Important
#include <stdio.h>

int main(void)
{
  printf("Be careful!!\n\a");
  return 0;
}
```

```code
// Program 1.7 A longer program
#include <stdio.h>          // Include the header file for input and output

int main(void)
{
  printf("Hi there!\n\n\nThis program is a bit");
  printf(" longer than the others.");
  printf("\nBut really it's only more text.\n\n\n\a\a");
  printf("Hey, wait a minute!! What was that???\n\n");
  printf("\t1.\tA bird?\n");
  printf("\t2.\tA plane?\n");
  printf("\t3.\tA control character?\n");
  printf("\n\t\t\b\bAnd how will this look when it prints out?\n\n");
  return 0;
}
```
