/* Program 1.4 Another Simple C Program - Displaying a Quotation */
#include <stdio.h>

int main(void)
{
  printf("My formula for success?\nRise early, work late, strike oil.\n");
  return 0;
}

