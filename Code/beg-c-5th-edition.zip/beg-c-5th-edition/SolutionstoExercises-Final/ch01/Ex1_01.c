// Exercise 1.1 Output a name and address
#include <stdio.h>

int main(void)
{
  printf("George Washington\n");
  printf("3200 George Washington Memorial Parkway\n");
  printf("Mount Vernon\n");
  printf("Virginia 22121\n");
  return 0;
}
