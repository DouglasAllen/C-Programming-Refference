// Exercise 1.3 Output a name and address
#include <stdio.h>

int main(void)
{
  // The double quotes within the string must appear as the escape sequence \".
  // This prevents them from being identified as the end of the string.
  printf("\"It's freezing in here,\" he said coldly.\n");
  return 0;
}
