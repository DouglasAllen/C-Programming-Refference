// Program 2.3 Using more variables 
#include <stdio.h>

int main(void)
{
  int brothers;                             // Declare a variable called brothers
  int brides;                               // and a variable called brides

  brothers = 7;                             // Store 7 in the variable brothers
  brides = 7;                               // Store 7 in the variable brides

  // Display some output
  printf("%d brides for %d brothers\n", brides, brothers);
  return 0;
}
