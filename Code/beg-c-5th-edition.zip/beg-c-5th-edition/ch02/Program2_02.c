//  Program 2.2 Using a variable
#include <stdio.h>

int main(void)
{
  int salary;                               // Declare a variable called salary
  salary = 10000;                           // Store 10000 in salary
  printf("My salary is %d.\n", salary);
  return 0;
}
