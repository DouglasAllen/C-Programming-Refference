// Program 2.3A Using more variables   
// This variation on Program 2.3 does not compile
#include <stdio.h>

int main(void)
{
  int brothers;                             // Declare a variable called brothers
  int brides;                               // and a variable called brides

  brothers = 7;                             // Store 7 in the variable brothers
  brides = 7;                               // Store 7 in the variable brides

  /* Display some output */
  printf("%d brides for %d brothers\n", Brides, brothers);
  return 0;
}

