/* Solar System Model  */
/* by John Abercrombie */
/* and Jason Davis     */ 


#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "data.c"

/* Define Object Sizes */
#define SUN_SIZE     14.0014504979
#define MERCURY_SIZE  0.048785054753
#define VENUS_SIZE    0.121052541562
#define EARTH_SIZE    0.127573217181
#define MARS_SIZE     0.067947039316
#define JUPITER_SIZE  1.42814795049
#define SATURN_SIZE   1.20712506211
#define URANUS_SIZE   0.517053572114
#define NEPTUNE_SIZE  0.486050354217
#define PLUTO_SIZE    0.022802362851

/* conversion ratio for Astronomical Units     */
/* not exactly correc the decimal point should */
/* be at the end of the number, but because of */
/* OpenGL's coordinate system, we wanted to    */
/* make everything smaller                     */
#define AU_TO_KM 1496.13400

/* define two-pi and how to get Radians */
#define TWOPI 2*PI 
#define RADS PI/180

/* setup planet number for objectinfo array */
#define MERCURY 0
#define VENUS   1
#define EARTH   2
#define MARS    3
#define JUPITER 4
#define SATURN  5
#define URANUS  6
#define NEPTUNE 7
#define PLUTO   8

/* define a planet ratio (just to see the planets) */
#define PLANET_RATIO 100

/* define number of entries into GLUlookat for camera array */
#define NUM_ENTRIES 9 

/* data.c function declarations */
double GetDaysTillJ2000(int, int, int, int);
int int_part(double);
double range(double);
double kep(double,double,int);
void planetpos(int, double);
int sgn(double);

/* ss.c function declarations */
void setView(int);

/* some variable declarations */
static short int year = 1998, month = 1, day = 1, hour = 1, minute = 1;   

/* the camera array */
double camera[NUM_ENTRIES] = { 0.0, 2000.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0 };

/* the current view       */
/* 0-8 planets            */
/* 10  sun                */
/* 11  other - stationary */  
int current_view = 11;

/* the window size - needed for mouse movement */
int window_x = 500;
int window_y = 500;

/* some GL variable declarations */
static GLfloat white[3]     = { 1.0,  1.0,  1.0 };
static GLfloat c_sun[3]     = { 1.0,  0.75, 0.0 };
static GLfloat c_earth[3]   = { 0.0,  0.4,  0.7 };  
static GLfloat c_mercury[3] = { 0.7,  0.7,  0.7 }; 
static GLfloat c_venus[3]   = { 0.7,  0.7,  0.2 };
static GLfloat c_mars[3]    = { 1.0,  0.0,  0.0 };
static GLfloat c_jupiter[3] = { 0.8,  0.4,  0.1};
static GLfloat c_saturn[3]  = { 0.7,  0.5,  0.2};
static GLfloat c_uranus[3]  = { 0.1,  0.2,  0.8};
static GLfloat c_neptune[3] = { 0.0,  0.0,  1.0};
static GLfloat c_pluto[3]   = { 0.75, 0.75, 0.75};

void init(void) {
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glShadeModel (GL_SMOOTH);
}

void display(void)
{

   double eldate;
   double days_till;


   /* the date is now declared (using the variables year, month, hour, day, minute) before any functions */

     
   days_till = GetDaysTillJ2000(year, month, day, hour);

   glEnable(GL_COLOR_MATERIAL);
   glColorMaterial(GL_FRONT, GL_DIFFUSE);
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glColor3f (1.0, 1.0, 1.0);
 
   /* code is messy, but added this in to follow the planet as it moves */
   setView(current_view);
   
   glPushMatrix();

   /* SUN */
   glColor3fv(c_sun);
   glTranslated(0.0, 0.0, 0.0);       
   glutSolidSphere(SUN_SIZE, 20, 16);

   glPopMatrix();

   glPushMatrix();
  
   /* MERCURY */
   planetpos(MERCURY, days_till);
   glColor3fv(c_mercury);
   glTranslated(xyz[MERCURY][0], xyz[MERCURY][1], xyz[MERCURY][2]); 
   glutSolidSphere(MERCURY_SIZE * PLANET_RATIO, 20, 16);
    
   glPopMatrix();
 
   glPushMatrix();
 
   /* VENUS   */
   planetpos(VENUS, days_till); 
   glColor3fv(c_venus);
   glTranslated(xyz[VENUS][0], xyz[VENUS][1], xyz[VENUS][2]); 
   glutSolidSphere(VENUS_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();

   /* EARTH   */
   planetpos(EARTH, days_till); 
   glColor3fv(c_earth);
   glTranslated(xyz[EARTH][0], xyz[EARTH][1], xyz[EARTH][2]);
   glutSolidSphere(EARTH_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();

   /* MARS    */
   planetpos(MARS, days_till); 
   glColor3fv(c_mars);
   glTranslated(xyz[MARS][0], xyz[MARS][1], xyz[MARS][2]);
   glutSolidSphere(MARS_SIZE * PLANET_RATIO, 20, 16);
 
   glPopMatrix();

   glPushMatrix();
 
   /* JUPITER */ 
   planetpos(JUPITER, days_till); 
   glColor3fv(c_jupiter);
   glTranslated(xyz[JUPITER][0], xyz[JUPITER][1], xyz[JUPITER][2]);
   glutSolidSphere(JUPITER_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();

   /* SATURN  */
   planetpos(SATURN, days_till); 
   glColor3fv(c_saturn);
   glTranslated(xyz[SATURN][0], xyz[SATURN][1], xyz[SATURN][2]);
   glutSolidSphere(SATURN_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();
   
   /* URANUS  */
   planetpos(URANUS, days_till);
   glColor3fv(c_uranus); 
   glTranslated(xyz[URANUS][0], xyz[URANUS][1], xyz[URANUS][2]);
   glutSolidSphere(URANUS_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();

   /* NEPTUNE */
   planetpos(NEPTUNE, days_till); 
   glColor3fv(c_neptune);
   glTranslated(xyz[NEPTUNE][0], xyz[NEPTUNE][1], xyz[NEPTUNE][2]);
   glutSolidSphere(NEPTUNE_SIZE * PLANET_RATIO, 20, 16);

   glPopMatrix();

   glPushMatrix();

   /* PLUTO */
   planetpos(PLUTO, days_till);
   glColor3fv(c_pluto); 
   glTranslated(xyz[PLUTO][0], xyz[PLUTO][1], xyz[PLUTO][2]);
   glutSolidSphere(PLUTO_SIZE * PLANET_RATIO, 20, 16);   
   
   glPopMatrix();
   
   glutSwapBuffers();
   
}

void reshape (int w, int h)
{
  /* initial camera positioning is defined in the creation of the camera array  */ 
   window_x = w;
   window_y = h;
 
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluPerspective(90.0, /* (GLfloat) w/ (GLfloat) h */ 1.0, 1.0, 100000.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity ();
   gluLookAt(camera[0], camera[1], camera[2], camera[3], camera[4], camera[5], camera[6], camera[7], camera[8]);
}


void setView(int view) {


  if ((view == MERCURY) || (view == VENUS) || (view == EARTH) || (view == MARS) || (view == JUPITER) || (view == SATURN) || (view == URANUS) || (view == NEPTUNE) || (view == PLUTO)) {
    camera[0] = xyz[view][0];
    camera[1] = xyz[view][1];
    camera[2] = 100 + xyz[view][2];
  
    camera[3] = xyz[view][0];
    camera[4] = xyz[view][1];
    camera[5] = xyz[view][2];
 
    camera[6] = 0.0;
    camera[7] = 1.0;
    camera[8] = 0.0;
  }
  else if (view == 10) {
    camera[0] = 0.0;
    camera[1] = 0.0;
    camera[2] = 100.0;
  
    camera[3] = 0.0;
    camera[4] = 0.0;
    camera[5] = 0.0;
 
    camera[6] = 0.0;
    camera[7] = 1.0;
    camera[8] = 0.0;
  }
  
  current_view = view;
  
  gluLookAt(camera[0], camera[1], camera[2], camera[3], camera[4], camera[5], camera[6], camera[7], camera[8]); 

}  


void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
     /* near Sun */
     case 's':
       glLoadIdentity(); 
       setView(10);
       glutPostRedisplay(); 
       break;

     /* near Mercury */     
     case 'r':
       glLoadIdentity();
       setView(MERCURY);
       glutPostRedisplay();
       break;

     /* near Venus */     
     case 'v':
       glLoadIdentity();
       setView(VENUS);
       glutPostRedisplay();
       break;     

     /* near Earth */     
     case 'e':
       glLoadIdentity();
       setView(EARTH);
       glutPostRedisplay();
       break; 

     /* near Mars */     
     case 'a':
       glLoadIdentity();
       setView(MARS);
       glutPostRedisplay();
       break; 

     /* near Jupiter */     
     case 'j':
       glLoadIdentity();
       setView(JUPITER);
       glutPostRedisplay();
       break;         

     /* near Saturn */     
     case 't':
       glLoadIdentity();
       setView(SATURN);
       glutPostRedisplay();
       break; 

     /* near Uranus */     
     case 'u':
       glLoadIdentity();
       setView(URANUS);
       glutPostRedisplay();
       break; 

     /* near Neptune */     
     case 'n':
       glLoadIdentity();
       setView(NEPTUNE);
       glutPostRedisplay();
       break; 

     /* near Pluto */     
     case 'p':
       glLoadIdentity();
       setView(PLUTO);
       glutPostRedisplay();
       break; 


     case 'H':
       if (hour >= 23) { 
         day  = day+1;
         hour = 1;
         if (day >= 30) {
           day   = 1;
           month = month+1;
           if (month >= 12) {
             year  = year+1;
             month = 1;
             day   = 1;
             hour  = 1;
           }
         }
       }
       else
         hour = hour + 1;
          
       glutPostRedisplay();
       break;
 
     case 'h':
       if (hour <= 1) {
         hour = 23;
         day  = day-1;
         if (day <= 1) {
           day   = 30;
           month = month-1;
           if (month = 1) {
             year  = year-1;
             month = 12;
             day   = 30;
             hour  = 23;
           }
         }
       }
       else
         hour = hour - 1;
       glutPostRedisplay();
       break;
 
     case 'D':
       if (day >= 30) {
         day   = 1;
         month = month+1;
         if (month >= 12) {
           year  = year+1;
           month = 1;
           day   = 1;
         }
       }
       else
         day = day + 1;
       glutPostRedisplay();
       break;

    case 'd':
      if (day <= 1) {
        day   = 30;
        month = month-1;
        if (month <= 1) {
          year  = year-1;
          month = 12;
          day   = 30;
        }
      }
      else
        day = day - 1;
      glutPostRedisplay();
      break;

    case 'M':
      if (month >= 12) {
        year  = year+1;
        month = 1;
        day   = 1;
        hour  = 1;
      }
      else 
        month = month + 1;

      glutPostRedisplay();
      break;

      case 'm':
        if (month <= 1) {
          year  = year-1;
          month = 12;
          day   = 30;
          hour  = 23;
        }
        else 
          month = month - 1;

        glutPostRedisplay();
        break;

      case 'Y':
        year = year + 1;
        glutPostRedisplay();
        break;
      case 'y':
        year = year - 1;
        glutPostRedisplay();
        break;
      case 27:
        exit(0);
        break;
      default:
        break;
   }
}

void mouse (int button, int state, int x, int y) {

  int x_axis, y_axis;

  x_axis = window_x / 2;
  y_axis = window_y / 2; 

  glLoadIdentity();
  current_view = 12;

  if (button == GLUT_RIGHT_BUTTON) {
    if (y > y_axis)
      camera[2] = camera[2] - (y - y_axis);
    else
      camera[2] = camera[2] + (y - y_axis);    
  }
  else if (button == GLUT_LEFT_BUTTON) {
    if (x > x_axis)
      camera[0] = camera[0] + (x - x_axis);
    else
      camera[0] = camera[0] - (x - x_axis); 
  }
  else if (button == GLUT_MIDDLE_BUTTON) {
    if (y > y_axis)
      camera[1] = camera[1] + (y - y_axis);
    else
      camera[1] = camera[1] - (y - y_axis);
  }    
     
  gluLookAt(camera[0], camera[1], camera[2], camera[3], camera[4], camera[5], camera[6], camera[7], camera[8]);
  glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize (window_x, window_y); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMouseFunc(mouse);
   glutMainLoop();
   return 0;
}







