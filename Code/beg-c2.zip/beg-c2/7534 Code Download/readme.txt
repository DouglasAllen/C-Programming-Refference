The zip will have unpacked into two folders, one containing the code from the book and the other
 the solutions to the exercises. The names of the files identify the chapter number and the sequence within a chapter so the
file Program2_07.c is the seventh example in Chapter 2, and Ex13_02.c is the solution to the second exercise in Chapter 13.

The solutions to the exercises that I have provided are not necessarily unique,
or even the best solutions. If your solution is different but works, then you have
clearly been successful in completing the exercise.

I hope you are enjoying learning C and I wish you every success.

Ivor Horton
