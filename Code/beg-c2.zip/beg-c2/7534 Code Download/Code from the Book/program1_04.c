/* Program 1.4 Another Simple C Program - Displaying a Quotation */
#include <stdio.h>

int main(void)
{
  printf("\nMy formula for success?\nRise early, work late, strike oil.");
  return 0;
}

