/* Program 1.5 Another Simple C Program - Displaying Great Quotations */
#include <stdio.h>

int main(void)
{
  printf("\n\"It is a wise father that knows his own child.\" Shakespeare");
  return 0;
}

