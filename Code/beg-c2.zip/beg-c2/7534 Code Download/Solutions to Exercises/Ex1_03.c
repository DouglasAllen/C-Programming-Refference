/* Exercise 1.3 Output a name and address */
#include <stdio.h>

int main(void)
{
  /* The double quotes must appear as the escape sequence \" */
  printf("\n\"It's freezing in here,\" he said coldly.\n");
  return 0;
}
