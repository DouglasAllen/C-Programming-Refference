/* list_solved.h
 *
 * Lists the digits on the given file pointer
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef LIST_SOLVED
#define LIST_SOLVED

#include <stdio.h>

void list_solved(FILE*);

#endif
