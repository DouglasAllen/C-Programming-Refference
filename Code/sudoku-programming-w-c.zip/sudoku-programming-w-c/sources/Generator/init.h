/* init.h
 *
 * Initializes a sudoku grid.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef INIT
#define INIT

void init(void);

#endif
