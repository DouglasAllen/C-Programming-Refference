/* fill_digit.h
 *
 * Fills in one digit
 *
 * Returns zero if everything is OK
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef FILL_DIGIT
#define FILL_DIGIT

int fill_digit(char i);

#endif
