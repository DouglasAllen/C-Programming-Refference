/* fill.h
 *
 * Fills in a Sudoku
 *
 * Returns zero if everything is OK
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef FILL
#define FILL

int fill(void);

#endif
