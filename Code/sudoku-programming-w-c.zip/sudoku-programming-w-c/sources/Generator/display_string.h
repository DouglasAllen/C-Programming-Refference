/* display_string.h
 *
 * Displays the sudoku string.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef DISPLAY_STRING
#define DISPLAY_STRING

void display_string(char *name);

#endif
