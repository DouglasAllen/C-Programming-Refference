/* save_html.h
 *
 * Saves a puzzle to disk as a web page
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef SAVE_HTML
#define SAVE_HTML

void save_html(char *puzzle, int seed, char *suffix);

#endif
