/* count_solved.h
 *
 * Counts the number of solved cells.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef COUNT_SOLVED
#define COUNT_SOLVED

int count_solved(void);

#endif
