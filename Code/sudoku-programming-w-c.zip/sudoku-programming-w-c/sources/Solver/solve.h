/* solve.h
 *
 * Solves a Sudoku without backtracking.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef SOLVE
#define SOLVE

void solve();

#endif
