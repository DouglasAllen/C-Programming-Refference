/* execute_strategies.h
 *
 * Loops through all strategies of a unit as long as something happens.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef EXECUTE_STRATEGIES
#define EXECUTE_STRATEGIES

int execute_strategies(int);

#endif
