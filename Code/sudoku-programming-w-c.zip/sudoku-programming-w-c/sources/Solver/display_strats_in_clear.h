/* display_strats_in_clear.h
 *
 * Displays the list of strategy used
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef DISPLAY_STRATS_IN_CLEAR
#define DISPLAY_STRATS_IN_CLEAR

void display_strats_in_clear();

#endif
