/* display.h
 *
 * Displays the sudoku grid.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef DISPLAY
#define DISPLAY

void display(void);

#endif
