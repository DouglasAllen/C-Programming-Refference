/* cleanup.h
 *
 * Removes duplicate numbers from rows, columns, and boxes.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef CLEANUP
#define CLEANUP

void cleanup(void);

#endif
