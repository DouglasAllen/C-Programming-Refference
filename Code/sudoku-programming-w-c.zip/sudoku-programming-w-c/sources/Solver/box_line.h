/* box_line.h
 *
 * box-line strategy.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef BOX_LINE
#define BOX_LINE

int box_line(void);

#endif
