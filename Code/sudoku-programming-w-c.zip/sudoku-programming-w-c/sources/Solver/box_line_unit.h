/* box_line_unit.h
 *
 * box-line strategy.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef BOX_LINE_UNIT
#define BOX_LINE_UNIT

int box_line_unit(int, char[9][2]);

#endif
