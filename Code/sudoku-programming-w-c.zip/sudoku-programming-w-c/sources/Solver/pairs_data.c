/* pairs_data.c
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#include "pairs_data.h"

char n_x_pairs[10][10] = {{0}};
char *x_pairs[10][10][3] = {{{0}}};  // 0= row, 1=column, 2=box
