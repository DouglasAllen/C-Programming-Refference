/* cleanup_around.h
 *
 * Removes duplicate numbers around a cell.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef CLEANUP_AROUND
#define CLEANUP_AROUND

void cleanup_around(int, int);

#endif
