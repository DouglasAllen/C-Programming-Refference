/* cleanup_unit.h
 *
 * Removes duplicate numbers from a unit.
 *
 * Copyright (C) 2015  Giulio Zambon  - http://zambon.com.au/
 *
 */
#ifndef CLEANUP_UNIT
#define CLEANUP_UNIT

void cleanup_unit(char*, int, int, char[9][2]);

#endif
