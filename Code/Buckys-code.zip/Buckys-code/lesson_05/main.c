#include <stdio.h>
#include <stdlib.h>

int main()
{
  //This is single line
  printf("Bucky is awesome \n");
  printf("Bucky is cool \a");
  return 0;

}
