#include <stdio.h>
#include <stdlib.h>

int main()
{
  printf("Bucky is awesome \n");
  printf("Bucky is cool \a");
  return 0;
}
