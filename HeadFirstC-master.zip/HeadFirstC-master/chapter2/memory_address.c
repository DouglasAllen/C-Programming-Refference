#include <stdio.h>

int main()
{
  int x = 0;
  printf("x is stored at %p\n", &x);
  return 0;
}
