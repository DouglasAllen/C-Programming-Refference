#include <stdio.h>

int main()
{
    char food[5];
    printf("Enter favorite food: ");
    scanf("%s", food);
    printf("Favorite food: %s", food);
    return 0;
}
