extern hello();

main()
{
    hello_();
}
