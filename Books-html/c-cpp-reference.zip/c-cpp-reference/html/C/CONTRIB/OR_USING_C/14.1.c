#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>

/*
 * setlim--set the resource limit lim to the value val.
 */
setlim(lim, val)
int lim, val;
{
    struct rlimit rlim;

    /*
     * First get the current limits so we
     * will know the maximum value.
     */
    getrlimit(lim, &rlim);

    /*
     * Now change the current limit.
     */
    rlim.rlim_cur = val;

    /*
     * Now set the new limit.
     */
    return(setrlimit(lim, &rlim));
}

