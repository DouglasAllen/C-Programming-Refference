#include <signal.h>

/*
 * work, work, work, all I ever do is work!
 */
dowork()
{
}

main()
{
    int mask;

    /*
     * Block SIGIO, which will indicate more
     * work to be done.
     */
    mask = sigmask(SIGIO);

    for (;;) {
        /*
         * Go do work.
         */
        dowork();

        /*
         * Pause until we receive a signal.
         * SIGIO is not blocked in mask.
         */
        sigpause(mask);
    }
}

