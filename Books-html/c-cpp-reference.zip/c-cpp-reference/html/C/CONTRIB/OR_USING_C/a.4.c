typedef struct {
	float r, i;
} complex;

main()
{
    extern complex y_();
    complex i;

    y_(&i);
}

x_(c)
complex *c;
{
    c->r = 1.0;
    c->i = 2.0;
}
