#define LOBYTE(x) ((unsigned char)(x))
#define HIBYTE(x) ((unsigned int)(x) >> 8)
