srand( ((unsigned int)time(NULL)) | 1);
