/* w_wrap.h */
/* prototypes for the functions in w_wrap.c */

char *word_wrap(char *string, size_t line_len);
void set_tab_size(size_t size);
