#include <stdio.h>
main()
{
    (void) printf("Hello World\n");
    return (0);
}
