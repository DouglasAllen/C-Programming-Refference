#include <stdlib.h>     /* using ANSI C standard libraries */
main()
{
    char *string_ptr;

    string_ptr = malloc(80);
