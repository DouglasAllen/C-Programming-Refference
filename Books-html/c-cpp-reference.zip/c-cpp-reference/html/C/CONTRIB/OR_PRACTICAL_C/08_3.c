main()
{

    init();
    solve_problems();
    finish_up();
}
