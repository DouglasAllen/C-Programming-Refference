main()
{
    (1 + 2) * 4;
    return (0);
}
