#include <windows.h>

// ID of Main Dialog
#define DLG_MAIN 100

// ID of Button Controls
#define IDC_BTN_TEST 101
#define IDC_BTN_QUIT 102
