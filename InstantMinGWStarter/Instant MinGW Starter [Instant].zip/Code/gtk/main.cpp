#include <gtk/gtk.h>

GtkWidget* CreateWindow()
{
	GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

	gtk_window_set_title(GTK_WINDOW (window), "Gtk+ Application");
	g_signal_connect(window, "delete-event", G_CALLBACK(gtk_main_quit), NULL);
	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

	return window;
}

void ShowMessage(GtkWidget* widget, gpointer data)
{
	GtkWidget* message = gtk_message_dialog_new((GtkWindow*)data, GTK_DIALOG_MODAL,
											    GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Message text");
	gtk_dialog_run(GTK_DIALOG(message));
	gtk_widget_destroy(message);
}

void CreateMsgButton(GtkWidget* box)
{
	GtkWidget* button = gtk_button_new_with_label("Message"); 
    gtk_widget_show(button);	
    g_signal_connect(G_OBJECT(button), "clicked",
                     G_CALLBACK(ShowMessage), NULL);
	gtk_container_add(GTK_CONTAINER(box), button);
}

void CreateQuitButton(GtkWidget* box)
{
	GtkWidget* button = gtk_button_new_with_label("Quit"); 
    gtk_widget_show(button);	
    g_signal_connect(G_OBJECT(button), "clicked",
                     G_CALLBACK(gtk_main_quit), NULL);
	gtk_container_add(GTK_CONTAINER(box), button);
}

int main(int argc, char* argv[])
{
	gtk_init(&argc, &argv);

	GtkWidget* window = CreateWindow();
	
	GtkWidget* box = gtk_vbox_new(FALSE, 0);
	gtk_widget_show(box);

	CreateMsgButton(box);
	
	CreateQuitButton(box);

    gtk_container_add(GTK_CONTAINER(window), box);
	gtk_widget_show(window);
	gtk_main();

	return 0;
}
